<?xml version="1.0" ?><!DOCTYPE TS><TS language="lt">
  <context>
    <name>osticket/createanissue</name>    
    <message>
      <source>Create a ticket in osTicket</source>
      <translation>Sukurti kortelę osTicket</translation>
    </message>
    <message>
      <source>Open a ticket in osTicket</source>
      <translation>Atidaryti kortelę osTicket</translation>
    </message>
    <message>
      <source>Create a ticket</source>
      <translation>Sukurti kortelę</translation>
    </message>
    <message>
      <source>You do not have permission to access a chat</source>
      <translation>Jūs neturitė teisės peržiūrėti pokalbio</translation>
    </message>
  </context>
</TS>